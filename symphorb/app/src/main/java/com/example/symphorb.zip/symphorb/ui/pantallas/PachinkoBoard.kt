package com.example.symphorb.ui.pantallas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.symphorb.utils.SimuladorPachinko
import com.example.symphorb.utils.SimuladorPachinko.Rebote

/**
 * Representa una posición lógica en la rejilla de pines
 */
data class Punto(val fila: Int, val columna: Int)

/**
 * Convierte una trayectoria de rebotes a una lista de posiciones de la bola en pantalla
 */
fun trayectoriaAPosiciones(trayectoria: SimuladorPachinko.Trayectoria): List<Punto> {
    val posiciones = mutableListOf<Punto>()
    var columnaActual = 0
    trayectoria.rebotes.forEachIndexed { fila, rebote ->
        if (rebote == Rebote.DERECHA) columnaActual += 1
        posiciones.add(Punto(fila, columnaActual))
    }
    return posiciones
}

/**
 * Dibuja la rejilla de pines y la trayectoria de la bola en base a una trayectoria lógica
 */
@Composable
fun PachinkoBoard(trayectoria: SimuladorPachinko.Trayectoria, filas: Int = 6) {
    val posiciones = remember(trayectoria) { trayectoriaAPosiciones(trayectoria) }

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(500.dp)
            .padding(16.dp)
    ) {
        val espacioX = size.width / (filas + 1)
        val espacioY = size.height / (filas + 1)

        // Dibujar pines (rejilla triangular)
        for (fila in 0 until filas) {
            for (columna in 0..fila) {
                val offsetX = espacioX * (columna + (filas - fila) / 2f + 0.5f)
                val offsetY = espacioY * (fila + 1)
                drawCircle(color = Color.Gray, radius = 8f, center = Offset(offsetX, offsetY))
            }
        }

        // Dibujar trayectoria de la bola
        posiciones.forEachIndexed { index, punto ->
            val offsetX = espacioX * (punto.columna + (filas - punto.fila) / 2f + 0.5f)
            val offsetY = espacioY * (punto.fila + 1)
            drawCircle(
                color = if (index == posiciones.lastIndex) Color.Red else Color.Blue,
                radius = 10f,
                center = Offset(offsetX, offsetY)
            )
        }
    }
}
