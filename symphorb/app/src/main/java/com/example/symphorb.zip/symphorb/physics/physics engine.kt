package com.example.symphorb.physics

import kotlin.math.*

/**
 * Representación física de una bola en movimiento bajo gravedad con rebotes.
 */
data class Vector2(val x: Float, val y: Float) {
    operator fun plus(other: Vector2) = Vector2(x + other.x, y + other.y)
    operator fun minus(other: Vector2) = Vector2(x - other.x, y - other.y)
    operator fun times(scalar: Float) = Vector2(x * scalar, y * scalar)
    fun magnitude() = sqrt(x * x + y * y)
    fun normalize() = if (magnitude() == 0f) this else this * (1f / magnitude())
    fun dot(other: Vector2) = x * other.x + y * other.y
}

/**
 * Clase pin física con colisión circular
 */
data class Pin(val position: Vector2, val radius: Float = 20f)

/**
 * Bola con posición, velocidad y masa
 */
data class Bola(
    var position: Vector2,
    var velocity: Vector2 = Vector2(0f, 0f),
    val radius: Float = 12f,
    val mass: Float = 1f
)

/**
 * Motor de físicas personalizado para simular movimiento con rebotes
 */
class PhysicsEngine(
    private val gravity: Vector2 = Vector2(0f, 980f), // píxeles/seg²
    private val damping: Float = 0.85f // pérdida de energía en cada rebote
) {
    val pins = mutableListOf<Pin>()
    var bola: Bola? = null

    fun setupBola(inicial: Vector2) {
        bola = Bola(position = inicial)
    }

    fun addPin(pin: Pin) {
        pins.add(pin)
    }

    fun simulate(deltaTime: Float) {
        bola?.let { bola ->
            // Aplicar gravedad
            bola.velocity = bola.velocity + gravity * deltaTime
            // Mover bola
            bola.position = bola.position + bola.velocity * deltaTime

            // Verificar colisiones
            pins.forEach { pin ->
                val diff = bola.position - pin.position
                val dist = diff.magnitude()
                val overlap = bola.radius + pin.radius - dist
                if (overlap > 0) {
                    val normal = diff.normalize()
                    bola.position = bola.position + normal * overlap // corregir penetración
                    val vDotN = bola.velocity.dot(normal)
                    val reflejada = bola.velocity - normal * (2 * vDotN)
                    bola.velocity = reflejada * damping
                }
            }
        }
    }

    fun reset() {
        pins.clear()
        bola = null
    }
}
