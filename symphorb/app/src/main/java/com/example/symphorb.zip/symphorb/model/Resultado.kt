package com.example.symphorb.model

data class Resultado(
    val nombre: String,
    val puntos: Int
)