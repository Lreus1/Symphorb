package com.example.symphorb.model

data class Pared(val inicio: Vector2D, val fin: Vector2D)