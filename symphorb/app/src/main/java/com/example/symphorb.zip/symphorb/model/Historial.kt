package com.example.symphorb.model

data class Historial(
    val fecha: String,
    val resultado: String,
    val puntos: Int
)